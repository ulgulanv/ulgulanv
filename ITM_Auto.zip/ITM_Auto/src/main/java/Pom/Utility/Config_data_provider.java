package Pom.Utility;

public class Config_data_provider {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
