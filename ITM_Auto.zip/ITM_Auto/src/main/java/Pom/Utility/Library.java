package Pom.Utility;

public final class Library {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
