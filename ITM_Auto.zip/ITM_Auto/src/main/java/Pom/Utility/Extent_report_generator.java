package Pom.Utility;

public class Extent_report_generator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
