package Pom.Utility;
import org.testng.annotations.BeforeSuite;

public class Base_class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         @BeforeSuite
	}

}
